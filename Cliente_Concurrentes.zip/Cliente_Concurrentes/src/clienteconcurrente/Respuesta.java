/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clienteconcurrente;

/**
 *
 * @author Usuario
 */
public class Respuesta {
    private String idSolicitud;
    private int idAccount;
    private int idDestination;
    private double saldoIdAccount;
    private double saldoIdDestination;
    private String type;//lectura o escritura

    public Respuesta(String idSolicitud, int idAccount, double saldoIdAccount, String type) {
        this.idSolicitud = idSolicitud;
        this.idAccount = idAccount;
        this.saldoIdAccount = saldoIdAccount;
        this.type = type;
    }

    public Respuesta(String idSolicitud, int idAccount, int idDestination, double saldoIdAccount, double saldoIdDestination, String type) {
        this.idSolicitud = idSolicitud;
        this.idAccount = idAccount;
        this.idDestination = idDestination;
        this.saldoIdAccount = saldoIdAccount;
        this.saldoIdDestination = saldoIdDestination;
        this.type = type;
    }

    public String getIdSolicitud() {
        return idSolicitud;
    }

    public void setIdSolicitud(String idSolicitud) {
        this.idSolicitud = idSolicitud;
    }

    public int getIdAccount() {
        return idAccount;
    }

    public void setIdAccount(int idAccount) {
        this.idAccount = idAccount;
    }

    public int getIdDestination() {
        return idDestination;
    }

    public void setIdDestination(int idDestination) {
        this.idDestination = idDestination;
    }

    public double getSaldoIdAccount() {
        return saldoIdAccount;
    }

    public void setSaldoIdAccount(double saldoIdAccount) {
        this.saldoIdAccount = saldoIdAccount;
    }

    public double getSaldoIdDestination() {
        return saldoIdDestination;
    }

    public void setSaldoIdDestination(double saldoIdDestination) {
        this.saldoIdDestination = saldoIdDestination;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
    
    
}
