/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package clienteconcurrente;

import java.util.Scanner;
import clienteconcurrente.TCPCliente;
import java.util.logging.Level;
import java.util.logging.Logger;


public class Cliente {
    TCPCliente mTcpClient;
    Scanner sc;
    String id_solicitud = "";
    String id;
    public Cliente(String id){
        this.id = id;
    }
    
    public static void main (String args[]){
        
        Scanner sc = new Scanner(System.in);
        System.out.println("Ingrese el identificador del Cliente: ");
        
        String id_cliente = sc.nextLine();
        Cliente cliente = new Cliente(id_cliente);
        cliente.iniciar();
        //cliente4.iniciar();
    }
    
        
	void iniciar(){
	   new Thread(
			new Runnable() {

				@Override
				public void run() {
					mTcpClient = new TCPCliente("192.168.1.34",
						new TCPCliente.OnMessageReceived(){
							@Override
							public void messageReceived(String message){
								ClienteRecibe(message);
							}
						}
					);
					mTcpClient.run();                   
				}
			}
		).start();
		//---------------------------
		String salir = "n";
		//sc = new Scanner(System.in);
                //System.out.println("Ingrese una solicitud: puede se de lectura (L) o actualizacion (A):\n1.-Formato de lectura (L): id_solicitud;id_account <> 02-L-1992;1039\n2.-Formato de actualización (A): id_solicitud;de;para;cantidad dinero <> 02-L-1992;8901;260;579.80\n");
		/*while( !salir.equals("q")){
                        //escribir una solicitud
			salir = sc.nextLine();
			ClienteEnvia(salir);
		}*/
                int i = 1;
                while(i<1000){
                    try {
                        Thread.sleep(10);
                        int indiceRandom = (int)(Math.random()*100);  //si es <60 es solicitud, sino es  actualizacion
                        if(indiceRandom <60){
                            
                            String solicitud = '0'+id+"-L-"+i+";"+(int)(Math.random()*10000 + 1);
                            ClienteEnvia(solicitud);
                        }else{
                            String solicitud = '0'+id+"-A-"+i+";"+(int)(Math.random()*10000 + 1)+";"+(int)(Math.random()*10000 + 1)+";"+(Math.round((Math.random()*500)* 100d) / 100d);
                            ClienteEnvia(solicitud);
                        }
                        i+=1;
                        
                    } catch (InterruptedException ex) {
                        Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
                    }

                    
                }
	
	}

	void ClienteRecibe(String llego){
            
                String[] response = llego.split(";");
                String[] idSoli = response[0].split("-");
                //System.out.println("respuesta: " + llego);
                if(("0"+this.id).equals(idSoli[0])){
                    System.out.println("respuesta: " + llego);
                }
                
		if(llego != null){
			System.out.flush();
		}
	}

	void ClienteEnvia(String envia){
		if (mTcpClient != null){
                    if(evaluarSolicitud(envia)){
                        mTcpClient.sendMessage(envia);
                    }else{
                        System.out.println("Formato invalido de solicitud");
                    }
                }
			
	}
        public boolean evaluarSolicitud(String envia){
            boolean flag = false;
            
            String[] parts = envia.split(";");
            
            if(parts.length==2){ // probable solicitud de lectura
                
                String[] subparts = parts[0].split("-");//veamos si cumple el formato de Lectura con la L en la posicion 1
               
                if(subparts.length==3){
                    if(subparts[1].equals("L")){
                        this.id_solicitud = parts[0];
                        flag = true;
                        return flag;
                    }
                }
            }else if(parts.length==4){ //probable solicitud de actualizacion
                String[] subparts = parts[0].split("-");//veamos si cumple el formato de Lectura con la A en la posicion 1
                if(subparts.length==3){
                    if(subparts[1].equals("A")){
                        this.id_solicitud = parts[0];
                        flag = true;
                        return flag;
                    }
                }
            }
            return flag;
        }
}
