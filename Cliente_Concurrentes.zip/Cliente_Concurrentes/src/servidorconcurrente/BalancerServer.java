package servidorconcurrente;

import clienteconcurrente.Peticion;
import clienteconcurrente.Respuesta;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import servidorconcurrente.BalancerServerTCP;

public class BalancerServer {
    volatile boolean ejecutar = true;
    BalancerServerTCP mTcpServer;
    Scanner sc;
    public static Queue<Peticion> queue;
    public static ArrayList<Replica> listReplicas = new ArrayList<Replica>();
    
    public static boolean bloquearCola = false;
    
    public static void main(String args[]) throws InterruptedException {
       BalancerServer server = new BalancerServer();
       queue =  new LinkedList<Peticion>();
       server.iniciar();
    }

    void iniciar() throws InterruptedException {
        iniciarReplicas(listReplicas,100);
        
        //mostrarReplica(listReplicas,0);
        //mostrarReplica(listReplicas,99);
        
        new Thread(
                new Runnable() {
                    @Override
                    public void run() {
                        mTcpServer = new BalancerServerTCP(
                                new BalancerServerTCP.OnMessageReceived() {
                                    @Override
                                    public void messageReceived(String message) {
                                        synchronized (this) {
                                            ServidorRecibe(message);
                                        }

                                    }

                                }
                        );
                        mTcpServer.run();
                    }
                }
        ).start();
        
        Thread.sleep(15000); //TIEMPO DE ESPERA PARA QUE SE CONECTEN LOS CLIENTES Y EMPIECE A DESENCOLAR ELEMENTOS
        //para que el servidor espere a que se pongan en cola algunas solicitudes
        //si no esperamos va a desencolar de inmediato el primer elemento, y no 
        //vamos a observar el proceso de cola
         new Thread(
                 new Runnable() {
                     public void run() {
                         while(ejecutar){
                             try {
                                Thread.sleep(10);
                            
                                    //aqui tendremos que agregar una condicion de parada
                                    //antes de sacar elementos de la cola
                                    //cuando haya una actualizacion
                                    if(bloquearCola == false){
                                        Peticion pedido = sacarCola();//sacamos de cola el pedido y vemos de que tipo es
                                        if(pedido!=null){
                                            if(pedido.getType().equals("lectura")){
                                                readCsv(pedido);
                                            }else if(pedido.getType().equals("actualizacion")){
                                                writeCsv(pedido);
                                            }
                                        }else{
                                            mostrarReplica(listReplicas,0);
                                            ejecutar = false;
                                        }
                                    }else{
                                        System.out.println("Cola bloqueada");
                                    }
                              } catch (InterruptedException ex) {
                                 Logger.getLogger(BalancerServer.class.getName()).log(Level.SEVERE, null, ex);
                             }
                         }
                         
                     }
                 }
         ).start();
        

    }

    void ServidorRecibe(String llego) {

        try {
            System.out.println("Desde el cliente: " + llego);
            
            String tipo = evaluarPeticion(llego);
            
            Peticion peticion;//solicitud que sera construida dependiendo de que tipo sea
                                //L -> lectura o A-> actualizacion
            
            if(tipo.equals("L")){

                peticion = lectura(llego);
                //System.out.println("pasamos la peticion");
                //ponemos en cola las solicitudes
                ponerEnCola(peticion);
                
            }else if(tipo.equals("A")){

                peticion = actualizacion(llego);
                //System.out.println("pasamos la peticion A");
                ponerEnCola(peticion);
               
            }
            

        } catch (NumberFormatException e) {
            // bla
        }

    }
    void readCsv(Peticion peticion){
        //aleatoriamente escogemos una de las replicas
        int indiceRandom = (int)(Math.random()*100); // de 0 a 99
        
        System.out.println("Accediendo al registro: "+indiceRandom);
        int flag = 0;// para verificar que exista el registro
        for(Csv element : listReplicas.get(indiceRandom).getReplica()){//recorremos la tabla dento de la replica
            if(element.getIdAccount() == peticion.getIdAccount()){//si existe el registro devolvemos un objeto con la 
                Respuesta respuesta = new Respuesta(peticion.getIdSolicitud(),peticion.getIdAccount(),element.getMoney(),peticion.getType());
                
                ServidorEnvia(respuesta.getIdSolicitud()+";"+respuesta.getIdAccount()+";"+respuesta.getSaldoIdAccount());
                flag = 1;
            }
            
        }
        if(flag == 0){
            ServidorEnvia("No existe ese registro en ninguna replica");
        }

    }
    
    void writeCsv(Peticion peticion){
        int indiceRandom = (int)(Math.random()*100); // de 0 a 99
        System.out.println("Accediendo al registro: "+indiceRandom);
        
        int posIdAccount = -1;
        int posIdDestination = -1;
        
        int flagIdAccount = 0;      // para verificar que exista el remitente
        int flagIdDestination = 0; // para verificar que exista el destinatario
        for(Csv element : listReplicas.get(indiceRandom).getReplica()){//recorremos la tabla dento de la replica
            if(element.getIdAccount() == peticion.getIdAccount()){
                posIdAccount = element.getIdAccount();
                //System.out.println("saldo "+peticion.getSaldoIdDestination());
                //System.out.println("de "+peticion.getIdAccount());
                //System.out.println("para "+peticion.getIdDestination());
                //System.out.println("idSolic "+peticion.getIdSolicitud());
                //System.out.println("money "+element.getMoney());
                if(element.getMoney() >= peticion.getSaldoIdDestination()){// verificamos que tenga suficiente saldo para la transaccion
                    flagIdAccount = 1;
                }

            }
            if(element.getIdAccount() == peticion.getIdDestination()){
                posIdDestination = element.getIdAccount();
                flagIdDestination = 1;
            }
        }
        if(flagIdAccount == 0){
            ServidorEnvia("No existe la cuenta o la cuenta no tiene el saldo suficiente");
        }
        if(flagIdDestination == 0){
            ServidorEnvia("No existe el destinatario");
        }
        
        if(flagIdAccount!=0 && flagIdDestination!=0){
            System.out.println("Imprimimos los valores antes de actualizar las replicas");
            System.out.println("saldo en la cuenta  "+(posIdAccount)+" es: "+listReplicas.get(indiceRandom).getReplica().get(posIdAccount-1).getMoney());
            System.out.println("saldo en la cuenta destino "+(posIdDestination)+" es: "+listReplicas.get(indiceRandom).getReplica().get(posIdDestination-1).getMoney());
            synchronized (this) {
                
                this.bloquearCola = true;//bloqueamos la cola antes de realizar la transaccion
                
                //vamos a modificar una replica y luego todas
                listReplicas.get(indiceRandom).getReplica().get(posIdAccount-1).removeMoney(peticion.getSaldoIdDestination());
                listReplicas.get(indiceRandom).getReplica().get(posIdDestination-1).addMoney(peticion.getSaldoIdDestination());
                
                Csv de = listReplicas.get(indiceRandom).getReplica().get(posIdAccount-1);
                Csv para = listReplicas.get(indiceRandom).getReplica().get(posIdDestination-1);
                
                Respuesta respuesta = new Respuesta(peticion.getIdSolicitud(),de.getIdAccount(),para.getIdAccount(),de.getMoney(),para.getMoney(),"actualizacion");
                //vamos a actualizar todas las replicas
                ArrayList<Csv> rows = listReplicas.get(indiceRandom).getReplica();
                Replica replica = new Replica();
                replica.setReplica(rows);
                int size = listReplicas.size();
                
                listReplicas.clear();//
                for(int i=0; i<size;i++){
                    listReplicas.add(replica);
                }
                
                ServidorEnvia(respuesta.getIdSolicitud()+";"+respuesta.getIdAccount()+";"+respuesta.getSaldoIdAccount()+";"+respuesta.getIdDestination()+";"+respuesta.getSaldoIdDestination());
                
                this.bloquearCola = false;
                
                
            }
            
        }
        //
        
        
        
        
        
    }

    void ServidorEnvia(String envia) {
        if (envia != null) {
            if (mTcpServer != null) {
                mTcpServer.sendMessageTCPServer(envia);
            }
        }
    }

    //funcion para ver que tipo de solicitud es
    
    public String evaluarPeticion(String recibe){
        String tipo = "N"; //ningun formato valido
        String[] parts = recibe.split(";");
        
        if(parts.length==2){ // probable solicitud de lectura
            String[] subparts = parts[0].split("-");//veamos si cumple el formato de Lectura con la L en la posicion 1
            if(subparts.length==3){
                if(subparts[1].equals("L")){
                    
                    tipo = "L";
                    return tipo;
                }
            }
        }else if(parts.length==4){ //probable solicitud de actualizacion
            
            String[] subparts = parts[0].split("-");//veamos si cumple el formato de Lectura con la L en la posicion 1
            if(subparts.length==3){
                if(subparts[1].equals("A")){
                    tipo = "A";
                    return tipo;
                }
            }
        }
        return tipo;
    }
    
    public Peticion lectura(String solicitud){
        
        String[] parts = solicitud.split(";");//en este punto ya sabemos que tiene tamaño 2
                                              //vamos a construir el objeto Solicitud del tipo lectura
                                              //en la clase Solicitud tenemos 2 metodos contructores
                                              //uno para lectura y otro para actualizacion
                                              
        String id_solicitud = parts[0];
        int id_account = Integer.parseInt(parts[1]);
                                             
        Peticion objSol = new Peticion(id_solicitud,id_account,"lectura");
        
        return objSol;
    }
    
    public Peticion actualizacion(String solicitud){
        String[] parts = solicitud.split(";");//en este punto ya sabemos que tiene tamaño 3
        
        String id_solicitud = parts[0];
        int de = Integer.parseInt(parts[1]);
        int para = Integer.parseInt(parts[2]);
        double cantidad_dinero = Double.parseDouble(parts[3]);
                                              
        Peticion objSol = new Peticion(id_solicitud,de,para,cantidad_dinero,"actualizacion");
        
        return objSol;
        
    }
    void ponerEnCola(Peticion pedido){
        queue.add(pedido);
        //System.out.println("cola "+queue.size());
    }

    Peticion sacarCola() {
        Peticion data = this.queue.peek();
        this.queue.poll();
        return data;
    }
    public void iniciarReplicas(ArrayList<Replica> listReplicas,int R){
        
        //llenamos cada replica con un registro csv unico
        ArrayList<Csv> registro = generateCsv();
        
        for(int i=0;i<R;i++){
            Replica replica = new Replica();
            replica.setReplica(registro);
            listReplicas.add(replica);
        }
    
    }
    public ArrayList<Csv> generateCsv(){
        ArrayList<Csv> listCsv = new ArrayList<Csv>();
        for(int i=1;i<=10000;i++){
            //double money = (Math.floor(Math.random() * (0 + 1)) + 1000); //generamos numeros entre 0 y 1000
            double money = 1000.0;
            Csv rowCsv = new Csv(i,money); //i = idAccount   money = Money
            listCsv.add(rowCsv);
        }
        return listCsv;
    }
    public void mostrarReplica(ArrayList<Replica> listReplica, int indice){
        mostrarCsv(listReplica.get(indice).getReplica());
    }
    
    
    public void mostrarCsv(ArrayList<Csv> replica){
        for(Csv element : replica){
            System.out.println("idAccount: "+element.getIdAccount()+ " Money: "+element.getMoney());
        }
    }
    
}
