/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servidorconcurrente;

/**
 *
 * @author Usuario
 */
public class Csv {
    private int idAccount;
    private double money;

    public Csv(int idAccount, double money) {
        this.idAccount = idAccount;
        this.money = money;
    }
   

    public int getIdAccount() {
        return idAccount;
    }

    public void setIdAccount(int idAccount) {
        this.idAccount = idAccount;
    }

    public double getMoney() {
        return money;
    }

    public void setMoney(double money) {
        this.money = money;
    }
    public void removeMoney(double money){
        this.money = this.money - money;
    }
    public void addMoney(double money){
        this.money = this.money + money;
    }
    
}
