/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servidorconcurrente;

import java.util.ArrayList;

/**
 *
 * @author Usuario
 */
public class Replica {
    public ArrayList<Csv> replica;

    public Replica() {
    }

    public Replica(ArrayList<Csv> replica) {
        this.replica = replica;
    }

    public ArrayList<Csv> getReplica() {
        return replica;
    }

    public void setReplica(ArrayList<Csv> replica) {
        this.replica = replica;
    }
    
    
}
